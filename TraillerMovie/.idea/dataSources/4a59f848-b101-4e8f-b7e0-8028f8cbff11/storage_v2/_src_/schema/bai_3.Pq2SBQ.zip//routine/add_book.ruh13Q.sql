create
    definer = root@localhost procedure add_book(IN id_book int, IN name_book varchar(255), IN psize int,
                                                IN id_authors int, IN id_cetegory int)
begin
    insert into books (id_b, name_b, page_size, id_a, id_c) VALUES (id_book,name_book,psize,id_authors,id_cetegory);
end;

