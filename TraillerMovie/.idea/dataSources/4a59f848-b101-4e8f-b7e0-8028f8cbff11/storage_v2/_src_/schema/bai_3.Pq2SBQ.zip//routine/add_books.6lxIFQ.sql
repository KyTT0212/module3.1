create
    definer = root@localhost procedure add_books(IN id int, IN name_book varchar(50), IN page_size int,
                                                 IN author_id int, IN category_id int)
begin
insert into books(id_b, name_b, page_size,id_a, id_c) values (id,name_book,page_size,author_id,category_id);
end;

