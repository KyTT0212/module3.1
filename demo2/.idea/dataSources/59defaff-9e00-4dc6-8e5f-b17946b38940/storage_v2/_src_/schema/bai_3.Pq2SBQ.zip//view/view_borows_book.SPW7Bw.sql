create definer = root@localhost view view_borows_book as
select `bai_3`.`books`.`name_b` AS `name_b`, count(`bai_3`.`borrows`.`id_br`) AS `sl`
from (`bai_3`.`books` join `bai_3`.`borrows` on ((`bai_3`.`books`.`id_b` = `bai_3`.`borrows`.`id_b`)))
group by `bai_3`.`books`.`name_b`
order by `sl`;

