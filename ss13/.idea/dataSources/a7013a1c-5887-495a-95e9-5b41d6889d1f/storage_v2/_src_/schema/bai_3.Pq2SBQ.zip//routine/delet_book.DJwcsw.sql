create
    definer = root@localhost procedure delet_book(IN id_book int)
begin
    delete from books where id_book;
end;

