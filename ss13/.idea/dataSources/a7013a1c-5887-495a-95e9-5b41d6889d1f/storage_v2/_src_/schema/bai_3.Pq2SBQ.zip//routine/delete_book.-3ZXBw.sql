create
    definer = root@localhost procedure delete_book(IN id_book int)
begin
    delete from books where id_b=id_book;
end;

